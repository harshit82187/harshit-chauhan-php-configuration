<html>

<head>
    <title>
        My DataTable
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="{{asset('assets/css/jquery.dataTables.min.css')}}" />
    <link rel="stylesheet" href="{{asset('assets/css/responsive.dataTables.min.css')}}" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
</head>

<body>


    <div class="white_box_tittle list_header">
        <h4> Carrer Page Listing </h4>
    </div>
    <div class="QA_table mb_30" style="background: #fff; padding: 25px;">
        @if (session()->get('success'))
        <div class="alert alert-success" role="alert">
            {{ session()->get('success') }}
        </div>
        @endif
        <table class="table lms_table_active" id="dataTable">
            <thead>
                <tr>
                    <th scope="col">S.no</th>
                    <th scope="col">Img</th>
                    <th scope="col">Prefix</th>
                    <th scope="col">Name</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Portfolio Link</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data as $carrer)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>
                        <div class="img-div  text-center" style="margin: 0 auto">
                            @if($data->b_image)
                            <a href="{{ asset('blog_images/'.$data->b_image) }}" download="{{ $data->b_image }}">
                                <img src="{{asset('blog_images/'.$data->b_image)}}" alt="" style="width:74px;height:85px;border-radius: 50%;">
                                @else
                                <img src="asset/Resources/img/Human icon.svg">
                                @endif
                        </div>
                    </td>
                    <td>
                        {{ Str::limit($data->s_answers, 15) }} <i class="fa fa-info-circle" data-toggle="tooltip" title="{{ $data->s_answers }}"></i>
                    </td>
                    <td>{{ $carrer->name }}</td>
                    <td>{{ $carrer->phone }}</td>
                    <td>{{ $carrer->email }}</td>
                    <td>{{ $carrer->portfolio }}</td> <!-- Removed </a> -->
                    <td class="d-flex">

                         <a href="{{ route('admin.edit_song', $song->id) }}" class="btn btn-info mr-2">Edit</a>
                         <a href="{{ route('admin.delete_song', $song->id) }}" class="btn btn-danger" onclick="return confirm('Are You Want To Sure?')">Delete </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
<script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('assets/js/dataTables.buttons.min.js') }}"></script> 
<script>
    $(document).ready(function() {
        $('#dataTable').DataTable();
    });
</script>
 


</body>

</html>